{
    'name': 'Archivar Productos con P',
    'version': '1.0',
    'category': 'Tools',
    'summary': 'Archiva productos cuya referencia interna contiene "P" y ademas verifica que no este en draft o sent',
    'author': 'Ing. Christian Padilla',
    'depends': ['base', 'product'],
    'data': [
        'views/res_users_view.xml',
    ],
    'installable': True,
    'application': False,
}
