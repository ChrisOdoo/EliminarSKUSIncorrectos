from odoo import models, api, _
from odoo.exceptions import UserError

class ResUsers(models.Model):
    _inherit = 'res.users'

    def archivar_productos_con_p(self):
        ProductTemplate = self.env['product.template']
        StockQuant = self.env['stock.quant']
        SaleOrderLine = self.env['sale.order.line']

        productos_p = ProductTemplate.search([
            ('default_code', 'ilike', 'P'),
            ('active', '=', True)
        ])

        if not productos_p:
            raise UserError("No se encontraron productos activos con la referencia que contiene 'P'.")

        errores = []
        exitosos = 0

        for producto_p in productos_p:
            codigo_p = producto_p.default_code or ''
            if not codigo_p.startswith('P'):
                continue

            # 1. Validar si está en una orden de venta en curso (excepto done)
            variantes_en_curso = SaleOrderLine.search([
                ('product_id.product_tmpl_id', '=', producto_p.id),
                ('order_id.state', 'in', ['draft', 'sent'])
            ])
            if variantes_en_curso:
                ordenes_ids = variantes_en_curso.mapped('order_id.name')
                errores.append(
                    f"Producto '{producto_p.default_code}' está en uso en cotizaciones: {', '.join(ordenes_ids)}"
                )
                continue  # No archivar este producto

            # 2. Buscar producto destino sin 'P'
            codigo_sin_p = codigo_p[1:].strip()
            producto_destino = ProductTemplate.search([
                ('default_code', '=', codigo_sin_p),
                ('active', '=', True)
            ], limit=1)

            if not producto_destino:
                errores.append(f"No se encontró producto destino para '{codigo_p}'")
                continue

            # 3. Mover stock
            quants_p = StockQuant.search([
                ('product_id.product_tmpl_id', '=', producto_p.id),
                ('quantity', '>', 0)
            ])

            for quant in quants_p:
                quant_destino = StockQuant.search([
                    ('product_id', '=', producto_destino.product_variant_id.id),
                    ('location_id', '=', quant.location_id.id)
                ], limit=1)

                if quant_destino:
                    quant_destino.quantity += quant.quantity
                else:
                    StockQuant.sudo().create({
                        'product_id': producto_destino.product_variant_id.id,
                        'location_id': quant.location_id.id,
                        'quantity': quant.quantity
                    })

                quant.quantity = 0

            # 4. Transferir avg_cost y standard_price
            producto_destino.product_variant_id.avg_cost = producto_p.product_variant_id.avg_cost
            producto_destino.standard_price = producto_p.standard_price

            producto_p.product_variant_id.avg_cost = 0.0
            producto_p.standard_price = 0.0

            # 5. Archivar
            producto_p.write({'active': False})
            exitosos += 1

        # 6. Mostrar mensaje final
        mensaje = []
        if exitosos:
            mensaje.append(f"Se archivaron {exitosos} producto(s).")
        if errores:
            mensaje.append("Advertencias:")
            mensaje += errores

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Resultado del Archivado',
                'message': "\n".join(mensaje),
                'type': 'success' if exitosos else 'warning',
                'sticky': True,
            }
        }
